import { createClient } from '@supabase/supabase-js';

const supabaseUrl = (import.meta as any).env?.VITE_SUPABASE_URL || 'https://bxueqraijepfwnhigsem.supabase.co';
const supabaseAnonKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || 'sb_publishable_ckhy8XaSq_nE5bD9-NsQXA_qPa2l9H0';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

