import { db, testFirestoreConnection } from '../lib/firebase';
import { collection, onSnapshot, doc, setDoc, getDocs, writeBatch } from 'firebase/firestore';
import {
  initialDriveFolders,
  initialSchedules,
  initialTransactions,
  initialTeachers,
  initialAnnouncements,
  initialOnlineMeeting,
  initialSchoolAccounts,
  initialLoginHistory
} from '../data/initialData';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    operationType,
    path
  };
  console.error('Firestore Error Details: ', JSON.stringify(errInfo));
}

const COLLECTIONS = {
  schedules: 'schedules',
  transactions: 'transactions',
  teachers: 'teachers',
  driveFolders: 'driveFolders',
  announcements: 'announcements',
  onlineMeeting: 'onlineMeeting',
  schoolAccounts: 'schoolAccounts',
  loginHistory: 'loginHistory'
};

const STORAGE_KEYS = {
  schedules: 'kkg6up_schedules',
  transactions: 'kkg6up_transactions',
  teachers: 'kkg6up_teachers',
  driveFolders: 'kkg6up_drive_folders',
  announcements: 'kkg6up_announcements',
  onlineMeeting: 'kkg6up_online_meeting',
  schoolAccounts: 'kkg6up_school_accounts',
  loginHistory: 'kkg6up_login_history'
};

// Seeding flag to prevent listener loopback
let isSyncingFromFirestore = false;
const lastLocalWriteTimestamps: Record<string, number> = {};
const pendingWrites: Record<string, boolean> = {};

export function isFirestoreSyncing(): boolean {
  return isSyncingFromFirestore;
}

export function sanitizeForFirestore(obj: any): any {
  if (obj === null || obj === undefined) {
    return null;
  }
  if (Array.isArray(obj)) {
    return obj.map(sanitizeForFirestore);
  }
  if (typeof obj === 'object' && obj !== null) {
    const cleaned: Record<string, any> = {};
    for (const key of Object.keys(obj)) {
      const val = obj[key];
      if (val !== undefined) {
        cleaned[key] = sanitizeForFirestore(val);
      }
    }
    return cleaned;
  }
  return obj;
}

// Function to sync local modifications directly to Cloud Firestore
export async function saveToFirestore(collectionName: string, data: any) {
  if (isSyncingFromFirestore) return;

  pendingWrites[collectionName] = true;
  lastLocalWriteTimestamps[collectionName] = Date.now();

  try {
    if (collectionName === COLLECTIONS.onlineMeeting) {
      // Single setting document
      const meetingRef = doc(db, 'settings', 'onlineMeeting');
      await setDoc(meetingRef, sanitizeForFirestore(data));
    } else if (Array.isArray(data)) {
      const colRef = collection(db, collectionName);
      const snapshot = await getDocs(colRef);
      
      const currentIds = new Set(data.map((item: any, index: number) => {
        const rawId = item.id || item.schoolName || ('doc-' + index);
        return String(rawId).replace(/[\/\s#\[\]]/g, '_').trim();
      }));

      const batch = writeBatch(db);

      // 1. Remove deleted items from Cloud Firestore
      snapshot.docs.forEach(d => {
        if (!currentIds.has(d.id)) {
          batch.delete(d.ref);
        }
      });

      // 2. Set/update current active items in Cloud Firestore
      data.forEach((item: any, index: number) => {
        const rawId = item.id || item.schoolName || ('doc-' + index);
        const safeId = String(rawId).replace(/[\/\s#\[\]]/g, '_').trim();
        if (safeId) {
          const itemRef = doc(db, collectionName, safeId);
          const payload = sanitizeForFirestore({ ...item, id: item.id || safeId });
          batch.set(itemRef, payload);
        }
      });

      await batch.commit();
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, collectionName);
  } finally {
    pendingWrites[collectionName] = false;
    lastLocalWriteTimestamps[collectionName] = Date.now();
  }
}

// Function to completely reset and rebuild Firestore collections with clean baseline data
export async function resetAndRebuildFirestoreData() {
  isSyncingFromFirestore = true;
  try {
    const seedCollection = async (colName: string, items: any[]) => {
      const colRef = collection(db, colName);
      const snapshot = await getDocs(colRef);
      const batch = writeBatch(db);

      // Delete existing documents
      snapshot.docs.forEach((docSnap) => {
        batch.delete(docSnap.ref);
      });

      // Insert clean items
      items.forEach((item: any, index: number) => {
        const rawId = item.id || item.schoolName || ('doc-' + index);
        const safeId = String(rawId).replace(/[\/\s#\[\]]/g, '_').trim();
        if (safeId) {
          const itemRef = doc(db, colName, safeId);
          const payload = sanitizeForFirestore({ ...item, id: item.id || safeId });
          batch.set(itemRef, payload);
        }
      });

      await batch.commit();
    };

    await seedCollection(COLLECTIONS.schedules, initialSchedules);
    await seedCollection(COLLECTIONS.transactions, initialTransactions);
    await seedCollection(COLLECTIONS.teachers, initialTeachers);
    await seedCollection(COLLECTIONS.driveFolders, initialDriveFolders);
    await seedCollection(COLLECTIONS.announcements, initialAnnouncements);
    await setDoc(doc(db, 'settings', 'onlineMeeting'), sanitizeForFirestore(initialOnlineMeeting));
    await seedCollection(COLLECTIONS.schoolAccounts, initialSchoolAccounts);
    await seedCollection(COLLECTIONS.loginHistory, initialLoginHistory);

    console.log('Cloud Firestore collections successfully rebuilt!');
  } catch (err) {
    console.error('Error resetting Firestore collections:', err);
  } finally {
    isSyncingFromFirestore = false;
  }
}

// Process incoming Cloud Firestore snapshot and update local cache verbatim
function processSnapshotData(
  collectionName: string,
  storageKey: string,
  snapshotDocs: any[],
  initialItems: any[]
) {
  // If a local write is currently pending or recently occurred (within 3s), ignore stale incoming snapshot
  if (pendingWrites[collectionName] || (Date.now() - (lastLocalWriteTimestamps[collectionName] || 0) < 3000)) {
    return;
  }

  let itemsToUse: any[];

  if (snapshotDocs.length === 0) {
    // Database collection is empty in Cloud Firestore
    // Check if local storage already has existing user data
    const localDataRaw = localStorage.getItem(storageKey);
    let existingLocalData: any = null;
    if (localDataRaw) {
      try {
        existingLocalData = JSON.parse(localDataRaw);
      } catch (e) {
        existingLocalData = null;
      }
    }

    if (existingLocalData && (Array.isArray(existingLocalData) ? existingLocalData.length > 0 : typeof existingLocalData === 'object')) {
      // Preserve local modified data and sync it to Cloud Firestore
      itemsToUse = existingLocalData;
      saveToFirestore(collectionName, existingLocalData);
    } else {
      // Both Firestore & local storage are empty -> Seed initial default dataset once
      itemsToUse = initialItems;
      saveToFirestore(collectionName, initialItems);
    }
  } else {
    // Cloud Firestore is the absolute source of truth across all devices
    itemsToUse = snapshotDocs;
  }

  isSyncingFromFirestore = true;
  try {
    localStorage.setItem(storageKey, JSON.stringify(itemsToUse));
  } catch (e) {
    console.warn(`Error updating local cache for ${storageKey}:`, e);
  }
  isSyncingFromFirestore = false;

  return itemsToUse;
}

// Subscribe to real-time updates from Cloud Firestore for all app collections
export function initFirestoreListeners(onUpdate: (key: string) => void) {
  testFirestoreConnection();

  try {
    // 1. Schedules
    onSnapshot(collection(db, COLLECTIONS.schedules), (snapshot) => {
      const items: any[] = [];
      snapshot.forEach(docSnap => items.push({ id: docSnap.id, ...docSnap.data() }));
      processSnapshotData(COLLECTIONS.schedules, STORAGE_KEYS.schedules, items, initialSchedules);
      onUpdate(STORAGE_KEYS.schedules);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, COLLECTIONS.schedules);
    });

    // 2. Transactions
    onSnapshot(collection(db, COLLECTIONS.transactions), (snapshot) => {
      const items: any[] = [];
      snapshot.forEach(docSnap => items.push({ id: docSnap.id, ...docSnap.data() }));
      processSnapshotData(COLLECTIONS.transactions, STORAGE_KEYS.transactions, items, initialTransactions);
      onUpdate(STORAGE_KEYS.transactions);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, COLLECTIONS.transactions);
    });

    // 3. Teachers
    onSnapshot(collection(db, COLLECTIONS.teachers), (snapshot) => {
      const items: any[] = [];
      snapshot.forEach(docSnap => items.push({ id: docSnap.id, ...docSnap.data() }));
      processSnapshotData(COLLECTIONS.teachers, STORAGE_KEYS.teachers, items, initialTeachers);
      onUpdate(STORAGE_KEYS.teachers);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, COLLECTIONS.teachers);
    });

    // 4. Drive Folders
    onSnapshot(collection(db, COLLECTIONS.driveFolders), (snapshot) => {
      const items: any[] = [];
      snapshot.forEach(docSnap => items.push({ id: docSnap.id, ...docSnap.data() }));
      processSnapshotData(COLLECTIONS.driveFolders, STORAGE_KEYS.driveFolders, items, initialDriveFolders);
      onUpdate(STORAGE_KEYS.driveFolders);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, COLLECTIONS.driveFolders);
    });

    // 5. Announcements
    onSnapshot(collection(db, COLLECTIONS.announcements), (snapshot) => {
      const items: any[] = [];
      snapshot.forEach(docSnap => items.push({ id: docSnap.id, ...docSnap.data() }));
      processSnapshotData(COLLECTIONS.announcements, STORAGE_KEYS.announcements, items, initialAnnouncements);
      onUpdate(STORAGE_KEYS.announcements);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, COLLECTIONS.announcements);
    });

    // 6. Online Meeting Settings
    onSnapshot(doc(db, 'settings', 'onlineMeeting'), (docSnap) => {
      if (!docSnap.exists()) {
        saveToFirestore(COLLECTIONS.onlineMeeting, initialOnlineMeeting);
        return;
      }
      const data = docSnap.data();
      if (data) {
        isSyncingFromFirestore = true;
        localStorage.setItem(STORAGE_KEYS.onlineMeeting, JSON.stringify(data));
        isSyncingFromFirestore = false;
        onUpdate(STORAGE_KEYS.onlineMeeting);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'settings/onlineMeeting');
    });

    // 7. School Accounts
    onSnapshot(collection(db, COLLECTIONS.schoolAccounts), (snapshot) => {
      const items: any[] = [];
      snapshot.forEach(docSnap => items.push({ schoolName: docSnap.id, ...docSnap.data() }));
      processSnapshotData(COLLECTIONS.schoolAccounts, STORAGE_KEYS.schoolAccounts, items, initialSchoolAccounts);
      onUpdate(STORAGE_KEYS.schoolAccounts);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, COLLECTIONS.schoolAccounts);
    });

    // 8. Login History Logs
    onSnapshot(collection(db, COLLECTIONS.loginHistory), (snapshot) => {
      const items: any[] = [];
      snapshot.forEach(docSnap => items.push({ id: docSnap.id, ...docSnap.data() }));
      processSnapshotData(COLLECTIONS.loginHistory, STORAGE_KEYS.loginHistory, items, initialLoginHistory);
      onUpdate(STORAGE_KEYS.loginHistory);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, COLLECTIONS.loginHistory);
    });

  } catch (err) {
    console.error('Error initializing Firestore listeners:', err);
  }
}
